## 如果你想学习vimscript,可以推荐一些资料给你

---

1. [Learn Vimscript in Y Minutes](https://learnxinyminutes.com/docs/vimscript/)

2. [[Learn Vimscript the Hard Way](https://learnvimscriptthehardway.stevelosh.com/)](https://learnvimscriptthehardway.stevelosh.com/)

3. https://learnvim.irian.to/

4. [Vimscript编程参考_w3cschool](https://www.w3cschool.cn/vim/nckx1pu0.html)

5. [Vimscript Tutorial - YouTube](https://www.youtube.com/playlist?list=PLOe6AggsTaVv_IQsADuzhOzepA_tSAagN)

6. https://zhuanlan.zhihu.com/p/37352209

7. [文档 - 章节目录 - [ 笨方法学Vimscript ] - 手册网](https://www.shouce.ren/api/view/a/9653)

8. [Introduction | learnvimscriptthehardway](https://huhuang03.gitbooks.io/learnvimscriptthehardway/content/)
