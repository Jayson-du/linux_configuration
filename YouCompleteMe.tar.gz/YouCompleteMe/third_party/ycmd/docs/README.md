API documentation
=================

This directory contains the API docs which are generated from the `openapi.yaml`
file. This file follows [the OpenAPI v2 specification][openapi]. When ycmd's API
changes, edit that file and run the `update_api_docs.py` script in the ycmd
folder to update the documentation.

[openapi]: https://github.com/OAI/OpenAPI-Specification/blob/master/versions/2.0.md
